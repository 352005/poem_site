//const button = document.querySelector('.btn');

const show = ()=>{
  const abt = document.querySelector('.abt');
  abt.classList.toggle('show');
}
